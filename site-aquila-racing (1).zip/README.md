# Site da Aquila Racing

Site oficial da Aquila Racing, equipa de STEM Racing Portugal da Escola Secundária de Fafe.
Está publicado em **https://aquilaracing.github.io** (português: `?lang=pt`, inglês: `?lang=en`).

## Acrescentar uma entrada ao Diário da época

O diário está no ficheiro **`diario.json`**. Não é preciso mexer no resto do site.

1. Neste repositório, abre o ficheiro `diario.json` e carrega no lápis (✏️ "Edit this file").
2. Logo a seguir ao primeiro `[`, cola este modelo e preenche-o:

```json
  {
    "data": "2026-12-03",
    "pt": { "titulo": "Título em português", "texto": "Uma ou duas frases sobre o que aconteceu." },
    "en": { "titulo": "Title in English", "texto": "One or two sentences about what happened." }
  },
```

3. Carrega em **"Commit changes"**. A entrada aparece no site em 1 a 2 minutos.

### Regras

- **Data:** sempre `ano-mês-dia` (`2026-12-03`). Se não souberes o dia, usa só `ano-mês` (`2026-12`). A ordem no ficheiro não importa: o site ordena sozinho, da mais recente para a mais antiga.
- **As duas línguas:** escreve sempre `pt` e `en`. Se faltar o inglês, quem vê o site em inglês lê a versão portuguesa.
- **Curto:** um título e uma ou duas frases. Não são notícias, são marcos.
- **Vírgulas:** cada entrada termina em `},` menos a última do ficheiro, que termina em `}` sem vírgula. Se o diário deixar de atualizar, quase sempre é uma vírgula a mais ou a menos. O site continua a funcionar e mostra as entradas antigas até o erro ser corrigido.
- **Ritmo:** uma entrada depois de cada reunião quinzenal.
- **O que não publicar:** valores de patrocínios por fechar, empresas que recusaram, problemas internos.

### Com fotografia (opcional)

1. Carrega a foto para a pasta `diario/` ("Add file" → "Upload files"). Usa JPG com menos de 300 KB.
2. Na entrada, acrescenta duas linhas:

```json
    "foto": "diario/nome-da-foto.jpg",
```

e, dentro de `pt` e de `en`, a descrição da foto para quem não a vê: `"foto_alt": "A equipa no CITEVE a testar o carro."`

A foto aparece na página do diário. Na página inicial também aparece, se a entrada estiver entre as 3 mais recentes.

## Não contar as visitas da equipa

Para que as visitas da equipa não entrem nas estatísticas (https://aquilaracing.goatcounter.com), cada membro abre **uma vez**, em cada computador e telemóvel que use, este link:

**https://aquilaracing.github.io/?naocontar=1**

Aparece em baixo a mensagem "Feito: este browser já não conta para as visitas do site." A partir daí, esse browser deixa de contar.

- Funciona por browser: o Chrome e o Safari do mesmo telemóvel contam como dois.
- Se apagarem os dados de navegação, ou usarem uma janela anónima, voltam a contar. Basta abrir o link outra vez.
- Para desfazer: https://aquilaracing.github.io/?naocontar=0

## Ficheiros

| Ficheiro ou pasta | Para quê |
|---|---|
| `index.html` | O site (textos, estilos e código). Para o atualizar, carrega um novo com o mesmo nome. |
| `img/` | As fotografias do site. Os nomes são códigos: não mudar nem apagar. |
| `js/` | O motor 3D da t-shirt (só é descarregado quando alguém chega a ela). |
| `fonts/` | A letra Montserrat, usada pela página de erro. |
| `diario.json` | As entradas do Diário da época. |
| `404.html` | Página para endereços errados: manda, por exemplo, `/parceiros` ou `/equipa` para a página certa. |
| `apple-touch-icon.png` | Ícone quando alguém guarda o site no ecrã do iPhone. |
| `og-image.jpg` | Imagem que aparece quando o link é partilhado. |
| `robots.txt`, `sitemap.xml` | Para o Google. |
| `googled3811a3ef284589b.html` | Prova ao Google que o site é nosso. **Nunca apagar.** |

## Código QR

O código QR da equipa abre `https://aquilaracing.github.io/?qr`. As visitas que chegam por ele aparecem no GoatCounter com a origem "QR code", por isso dá para saber quantas pessoas o leram no stand, no dossier ou nos cartões.

## Atenção ao alterar o `index.html`

- Os textos estão em inglês no HTML. A tradução para português está num dicionário dentro do código: **qualquer texto novo precisa da tradução**, senão aparece em inglês na versão portuguesa.
- O site tem uma política de segurança que só deixa correr os scripts conhecidos. **Se alterares algum script, a política tem de ser atualizada**, senão esse script deixa de funcionar.

Nos dois casos, o mais simples é pedir as alterações ao Claude, no projeto "STEM Racing".
